window.renderBubble = function renderBubble(ctx) {
  const root = document.getElementById('bubble');
  const content = document.getElementById('content');
  if (!root || !content) return;

  const text = String(ctx.text || '');
  const isMine = Boolean(ctx.isMine);
  const lengthClass = text.length > 120
    ? 'tall'
    : text.length > 56
      ? 'long'
      : text.length > 18
        ? 'medium'
        : 'short';

  document.body.className = isMine ? 'is-mine' : 'is-other';
  root.className = `bubble ${isMine ? 'mine' : 'other'} ${lengthClass}`;
  content.textContent = text;
  syncBubbleHeight();
};

function numberFromPx(value) {
  const next = parseFloat(value || '0');
  return Number.isFinite(next) ? next : 0;
}

function syncBubbleHeight() {
  const root = document.getElementById('bubble');
  const content = document.getElementById('content');
  if (!root || !content) return 0;

  root.style.height = 'auto';
  const rootStyle = window.getComputedStyle(root);
  const paddingTop = numberFromPx(rootStyle.paddingTop);
  const paddingBottom = numberFromPx(rootStyle.paddingBottom);
  const borderTop = numberFromPx(rootStyle.borderTopWidth);
  const borderBottom = numberFromPx(rootStyle.borderBottomWidth);
  const minHeight = numberFromPx(rootStyle.minHeight);
  const contentHeight = Math.max(
    content.scrollHeight,
    content.getBoundingClientRect().height,
  );
  const nextHeight = Math.max(
    minHeight,
    Math.ceil(contentHeight + paddingTop + paddingBottom + borderTop + borderBottom),
  );
  root.style.height = `${nextHeight}px`;
  return nextHeight;
}

window.measureBubble = function measureBubble() {
  const root = document.getElementById('bubble');
  if (!root) return 0;
  syncBubbleHeight();
  const rect = root.getBoundingClientRect();
  const bodyStyle = window.getComputedStyle(document.body);
  const paddingBottom = parseFloat(bodyStyle.paddingBottom || '0') || 0;
  return Math.ceil(rect.bottom + paddingBottom);
};
